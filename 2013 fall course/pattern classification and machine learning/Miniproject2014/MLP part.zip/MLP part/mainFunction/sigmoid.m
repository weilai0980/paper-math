function [ out ] = sigmoid( A )
%Usage: Compute sigmoid function

out=1./(1+exp(-A));

end


